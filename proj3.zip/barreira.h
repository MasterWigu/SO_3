#ifndef BARREIRA_H
#define BARREIRA_H


int waitBarreira(int iter, int desvio);
int initBarreira(int n_threads);
void destroyBarreira();




#endif